// Name:  Princess Mazagwu  
// VUnetID: mazagwpc
// Email: princess.c.mazagwu@vanderbilt.edu
// Class: CS 1101 - Vanderbilt University
// Section: 002 (MWF 1:10-2:00)
// Honor statement: I have not given or received unauthorized aid on this assignment.
// Date: 01/16/2018
// Description: Warmup Program: Hello World

public class BasicOutput {
   public static void main(String[] args) {
      System.out.println("Hello world!");
      System.out.println("How are you?");
      System.out.println("   (I'm fine).");   
   }
}